from django.http import HttpResponse
from django.shortcuts import render
from publication.models import publication
from blog.models import BlogPost
from django.core.paginator import Paginator

def home_page(request):
    pub_post = publication.objects.all().order_by('date').reverse()
    blog_post = BlogPost.objects.all().order_by('date').reverse()
    pub_paginator = Paginator(pub_post, 6)
    blog_paginator = Paginator(blog_post, 3)
    page = request.GET.get('page')
    pub_post = pub_paginator.get_page(page)
    blog_post = blog_paginator.get_page(page)
    template_name = "home.html"
    context = {"pub_object":pub_post,"blog_object":blog_post,"range":range(6),"title":"Home"}
    return render(request, template_name,context)
    # return render(request,"home.html",{"title":"Home","range": range(6)})