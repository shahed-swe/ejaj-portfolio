from django.contrib import admin
from .models import publication
# Register your models here.
admin.site.register(publication)