from django.shortcuts import render, get_object_or_404, redirect
from django.http import Http404
from django.shortcuts import render
from .models import publication
# Create your views here.
def publication_list_view(request):
    qs = publication.objects.all()
    template_name = 'publication/list.html'
    context = {'object_list':qs,"title":"Publication"}
    return render(request, template_name, context)

def publication_detail_view(request, post_slug):
    obj = get_object_or_404(publication, slug=post_slug)
    template_name = 'publication/detail.html'
    context = {"object":obj,"title":"Publication"}
    return render(request, template_name, context)


