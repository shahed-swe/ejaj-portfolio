from django.db import models

# Create your models here.
class publication(models.Model):
    slug = models.SlugField(blank=False, unique=True)
    book_name = models.CharField(max_length=120,null=True)
    author = models.CharField(max_length=120,null=True)
    date = models.DateField(null=True)
    publisher = models.CharField(max_length=120, null=True)
    description = models.TextField(max_length=1000, null=True)
    image_ban = models.ImageField(upload_to='image/',blank=True, null=True)
    image_cover = models.ImageField(upload_to='image/',blank=True,null=True)

    def get_absolute_url(self):
        return f"/publication/{self.slug}"