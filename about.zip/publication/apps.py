from django.apps import AppConfig


class PublicationConfig(AppConfig):
    name = 'publication'
