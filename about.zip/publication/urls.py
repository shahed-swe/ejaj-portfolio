from django.urls import path
from publication.views import (
    publication_list_view,
    publication_detail_view,
)

urlpatterns = [
    path('',publication_list_view),
    path('<str:post_slug>/',publication_detail_view),
]