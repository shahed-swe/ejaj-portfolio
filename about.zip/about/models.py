from django.db import models

# Create your models here.
class education(models.Model):
    slug = models.SlugField(blank=False, unique=True) 
    year = models.CharField(max_length=120,null=True)
    certificate = models.CharField(max_length=120,null=True)
    college_name = models.CharField(max_length=120,null=True)
    gpa = models.CharField(max_length=20,null=True)
    description = models.TextField(null=True)
    

class experience(models.Model):
    slug = models.SlugField(blank=False, unique=True)
    organization = models.CharField(max_length=120, null=True)
    designation = models.CharField(max_length=120, null=True)
    responsibility = models.CharField(max_length=120, null=True)
    description = models.TextField(null=True)
    image = models.ImageField(upload_to='images/',blank=True, null=True)
    
