from django.shortcuts import render
from about.models import education,experience
# Create your views here.
from blog.models import BlogPost

def about_page(request):
    qs_edu = education.objects.all()
    context = {"object_list_edu": qs_edu, "title":"About"}
    return render(request, 'about_full.html',context)

def experience_page(request):
    post_blog = BlogPost.objects.all()
    qs_exp = experience.objects.all()
    context = {"object_list_exp": qs_exp,"blog_object": post_blog,"title":"Experience"}
    return render(request, 'experience.html',context)
