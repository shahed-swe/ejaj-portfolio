from django.contrib import admin
from django.contrib.auth.models import Group
# Register your models here.
from .models import education,experience
admin.site.site_header = "Admin Control"
admin.site.register(education)
admin.site.register(experience)