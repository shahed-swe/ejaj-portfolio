from django.db import models
# from django.conf import settings


# Create your models here.

# User = settings.AUTH_USER_MODEL

class BlogPost(models.Model):
    
    slug = models.SlugField(blank=False, unique=True) 
    title = models.CharField(max_length=120)
    content = models.TextField(null = True,blank=True)
    about = models.TextField(null=True)
    time = models.TimeField()
    date = models.DateField()
    select = models.CharField(null = True,max_length=256, choices=[('it','Technology'),('food','Food'),('art','Art Of Living'),('project','Project')])
    image_cover = models.ImageField(upload_to='blog/cover/',null=True)
    image_take_one = models.ImageField(upload_to='blog/take/',null=True,blank=True)
    image_take_two = models.ImageField(upload_to='blog/take/',null=True,blank=True)

    def get_absolute_url(self):
        return f"/blog/{self.slug}"

    def get_edit_url(self):
        return f"{self.get_absolute_url()}/edit"
    
    def get_delete_url(self):
        return f"{self.get_absolute_url()}/delete"